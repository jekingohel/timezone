<?php
	include 'header.php';
	include 'class/medoo.min.php';
?>
	<div class="loader"><img src="assets/img/ajax-loader.gif"/></div>
	<h1 style="border-bottom:1px solid #0A7EE9">Calories Burned From Exercise</h1>
	<div class="container">
		<div class="control-group">
            <label class="control-label">Choose an exercise below: : </label>
            <div class="controls">
				<select name="exercise" id="exercise" style="width:40%">
					<?php
						$db = new medoo("weightloss");
						$data = $db->select("exe", "*");
						foreach($data as $d):
					?>
							<option data-mets="<?= $d['mets'] ?>" value="<?= $d['mets'] ?>"><?= $d['name'] ?></option>
					<?php
						endforeach;
					?>
				</select>
            </div>
        </div>
		<blockquote>
			<p style="color: #0A7EE9">How Many Calories Did I Burn?</p>
			<div class="control-group">
				<label class="control-label">Your Weight: </label>
				<div class="controls">
					<input type="text" name="weight" class="input-small"/><span class="help-inline">Pounds</span>
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">How Long: </label>
				<div class="controls">
					<input type="text" name="minutes" class="input-small"/><span class="help-inline">Minutes</span>
				</div>
			</div>
			<div class="control-group">
				<div class="controls">
					<button type="button" id="submit" class="btn btn-info" >Calculate</button>
				</div>
			</div>
			<div class="control-group" id="result">
				<label class="control-label"><b>Calories burned : </b><span id="cresults" style="color:#19791e;font-weight:bold">0</span></label>
			</div>
		</blockquote>
	</div>
<?php
	include 'footer.php';
?>
<script>
	$(document).ready(function(){
		$('#submit').click(function(){
			$('.loader').show();
			UpdateCaloriesBurned($('#exercise').val(),$('[name=minutes]').val(),$('[name=weight]').val())
			setTimeout(function(){ $('.loader').fadeOut(); },500)
		});
	});
	function UpdateCaloriesBurned(mets,minutes,weight) {
		var calorie_multiplier = 1;
		var new_weight = parseFloat(weight) || 0;
		$('#cresults').html(Math.round( ( mets * ( minutes / 60)*( new_weight * 0.453592 ) ) * calorie_multiplier));
	};
</script>