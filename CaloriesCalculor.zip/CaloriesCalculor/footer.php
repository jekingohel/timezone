			</div>
		</div>
		<script src="assets/js/jquery-1.9.0.js" type="text/javascript"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/select2.min.js"></script>
		<script src="assets/js/bootstrap-datepicker.js"></script>
		<script src="assets/js/bootstrap-timepicker.js"></script>
		<script src="assets/js/jquery.validate.js"></script>
		<script>
			$(document).ready(function(){
				$('select').select2();
			});
		</script>
	</body>
</html>